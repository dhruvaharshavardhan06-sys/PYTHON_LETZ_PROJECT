# 📊 Student Survey Dashboard

> **LocalImpact Challenge · Project #100 · Data & Visualization**

A fully-featured, browser-based Student Survey Dashboard built with vanilla HTML, CSS, and JavaScript — zero server required, no installation needed.

---

## 🚀 Quick Start

1. Open `index.html` directly in any modern browser (Chrome, Edge, Firefox).
2. Sample data (35 students) loads automatically on first visit.
3. All data persists in **localStorage** — survives browser restarts.

---

## ✨ Features

### Core (Must-Have)
| Feature | Details |
|---------|---------|
| 🏠 **Dashboard** | Live KPI cards (total, avg score, avg satisfaction, top department) |
| ➕ **Add Entry** | Guided form with real-time input validation |
| 📋 **Records** | Paginated table with search, multi-filter, edit, delete |
| 📈 **Analytics** | 6 Chart.js visualizations (scatter, bar, line, doughnut) |
| 💾 **Persistence** | localStorage — data survives page refreshes |
| 🔍 **Filter & Search** | Filter by name/ID, department, year, score range |
| 📊 **Executive Summary** | Totals, averages, department breakdown |

### Stretch (Good-to-Have)
| Feature | Details |
|---------|---------|
| 📤 **Multi-Format Export** | CSV, JSON, Markdown, Plain Text downloads |
| ⚠️ **Warning Indicators** | Auto-flags: low scores (<50), attendance (<60%), satisfaction (≤3) |
| 📥 **Bulk CSV Import** | Upload any CSV with automatic format validation & error reporting |

---

## 📁 File Structure

```
student-survey-dashboard/
├── index.html   — App shell, all pages & modals
├── style.css    — Full responsive design system
├── app.js       — All logic: CRUD, charts, filters, export
└── README.md    — This file
```

---

## 📊 Pages

### Dashboard
- 4 KPI summary cards
- Warning threshold indicators
- Score distribution bar chart
- Responses by department doughnut chart
- Recent 5 entries table

### Add Entry
- 8 validated fields (name, ID, department, year, score, satisfaction, study hours, attendance)
- Real-time field-level validation
- Duplicate ID detection

### Records
- Full paginated table (10 per page)
- Search by name or student ID
- Filter by department, year, score range
- In-row Edit ✏️ and Delete 🗑️
- Bulk CSV import with row-by-row validation

### Analytics
- 8 summary stat cards
- Scatter plot: Satisfaction vs Score
- Study hours & attendance histograms
- Avg score by department
- Year-wise satisfaction trend
- Score entry-order trend line

### Export
- One-click CSV, JSON, Markdown, Text downloads
- Live report preview in dark terminal style

---

## 🛡️ Validation Rules

| Field | Rule |
|-------|------|
| Name | 2+ characters |
| Student ID | 3–15 alphanumeric + hyphens |
| Department | Required selection |
| Year | Required selection |
| Score | Integer 0–100 |
| Satisfaction | Integer 1–10 |
| Study Hours | Integer 0–168 |
| Attendance | Integer 0–100 |

---

## 🗂️ CSV Import Format

Your CSV should have these headers (case-insensitive):
```
name, studentId, department, year, score, satisfaction, studyHours, attendance, feedback, date
```

---

## 🧰 Tech Stack

| Layer | Technology |
|-------|-----------|
| UI | Vanilla HTML5 + CSS3 (custom design system) |
| Logic | Vanilla JavaScript (ES6+, IIFE module pattern) |
| Charts | Chart.js 4.4.0 (CDN) |
| CSV Parse | Papa Parse 5.4.1 (CDN) |
| Storage | Browser localStorage |
| Fonts | Segoe UI / System UI |

---

*Built for LocalImpact Challenge · Project #100 — Domain: Data & Visualization*
