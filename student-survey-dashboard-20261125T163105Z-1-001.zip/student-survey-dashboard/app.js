/* =============================================
   Student Survey Dashboard — app.js
   Full featured: CRUD, charts, filters, export
   ============================================= */

'use strict';

// ============================================================
// DATA LAYER — localStorage persistence
// ============================================================
const STORAGE_KEY = 'survey_dashboard_v1';

function loadData() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch {
    return [];
  }
}

function saveData(records) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  } catch (e) {
    toast('⚠️ Could not save to localStorage: ' + e.message, 'error');
  }
}

// Seed realistic sample data if first load
function seedSampleData() {
  const depts = ['Computer Science','Mathematics','Physics','Engineering','Economics','Biology','English','History','Psychology','Chemistry'];
  const years = ['1st Year','2nd Year','3rd Year','4th Year','Postgraduate'];
  const names = [
    'Alice Johnson','Bob Smith','Carol White','David Lee','Eva Martinez',
    'Frank Brown','Grace Kim','Henry Davis','Irene Wilson','Jack Taylor',
    'Karen Anderson','Liam Thomas','Mia Jackson','Noah Harris','Olivia Martin',
    'Paul Thompson','Quinn Robinson','Rachel Clark','Sam Lewis','Tina Walker',
    'Uma Hall','Victor Allen','Wendy Young','Xavier Hernandez','Yara King',
    'Zoe Wright','Aaron Scott','Beth Green','Carl Adams','Dana Baker',
    'Elena Carter','Felix Mitchell','Gina Perez','Hugo Roberts','Iris Turner'
  ];
  const feedbacks = [
    'Great course material!','Needs more practical sessions.','Excellent professor support.',
    'Lab sessions were very helpful.','More examples needed.','Perfect pacing.',
    'Could use more interactive tools.','Very well-organized curriculum.',
    'Assignments were challenging but fair.','Loved the group projects!',''
  ];

  const records = [];
  for (let i = 0; i < 35; i++) {
    const score = Math.round(30 + Math.random() * 70);
    const satisfaction = Math.round(1 + Math.random() * 9);
    const studyHours = Math.round(5 + Math.random() * 45);
    const attendance = Math.round(50 + Math.random() * 50);
    const dept = depts[i % depts.length];
    records.push({
      id: generateId(),
      name: names[i],
      studentId: `STU-${String(i + 1).padStart(3, '0')}`,
      department: dept,
      year: years[i % years.length],
      score,
      satisfaction,
      studyHours,
      attendance,
      feedback: feedbacks[i % feedbacks.length],
      date: new Date(Date.now() - (35 - i) * 86400000 * 2).toISOString().split('T')[0]
    });
  }
  saveData(records);
  return records;
}

function generateId() {
  return Date.now().toString(36) + Math.random().toString(36).slice(2, 7);
}

// ============================================================
// VALIDATION
// ============================================================
const validators = {
  name: v => v.trim().length >= 2 ? '' : 'Name must be at least 2 characters.',
  studentId: v => /^[A-Za-z0-9\-]{3,15}$/.test(v.trim()) ? '' : 'ID: 3–15 alphanumeric chars (hyphens allowed).',
  dept: v => v ? '' : 'Please select a department.',
  year: v => v ? '' : 'Please select a year.',
  score: v => { const n = Number(v); return (!isNaN(n) && n >= 0 && n <= 100) ? '' : 'Score must be 0–100.'; },
  satisfaction: v => { const n = Number(v); return (!isNaN(n) && n >= 1 && n <= 10) ? '' : 'Satisfaction must be 1–10.'; },
  studyHours: v => { const n = Number(v); return (!isNaN(n) && n >= 0 && n <= 168) ? '' : 'Study hours must be 0–168.'; },
  attendance: v => { const n = Number(v); return (!isNaN(n) && n >= 0 && n <= 100) ? '' : 'Attendance must be 0–100.'; }
};

function validateField(field, value) {
  const fn = validators[field];
  return fn ? fn(value) : '';
}

// ============================================================
// TOAST
// ============================================================
function toast(msg, type = 'success', duration = 3000) {
  const container = document.getElementById('toast-container');
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  container.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; setTimeout(() => el.remove(), 300); }, duration);
}

// ============================================================
// CHART MANAGEMENT
// ============================================================
const chartInstances = {};

function destroyChart(id) {
  if (chartInstances[id]) {
    chartInstances[id].destroy();
    delete chartInstances[id];
  }
}

function createChart(id, config) {
  destroyChart(id);
  const ctx = document.getElementById(id);
  if (!ctx) return;
  chartInstances[id] = new Chart(ctx, config);
}

const PALETTE = ['#6366f1','#06b6d4','#22c55e','#f59e0b','#ef4444','#8b5cf6','#ec4899','#14b8a6','#f97316','#84cc16'];

// ============================================================
// SCORE BADGE
// ============================================================
function scoreBadge(score) {
  let cls, label;
  if (score >= 90) { cls = 'score-excellent'; label = score; }
  else if (score >= 75) { cls = 'score-good'; label = score; }
  else if (score >= 50) { cls = 'score-avg'; label = score; }
  else { cls = 'score-low'; label = score; }
  return `<span class="score-badge ${cls}">${label}</span>`;
}

// ============================================================
// MAIN APP
// ============================================================
const app = (() => {
  let records = [];
  let filteredRecords = [];
  let currentPage = 1;
  const PAGE_SIZE = 10;

  // ---- NAVIGATION ----
  function nav(pageName) {
    document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
    document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
    const page = document.getElementById('page-' + pageName);
    if (page) page.classList.add('active');
    const navItem = document.querySelector(`[data-page="${pageName}"]`);
    if (navItem) navItem.classList.add('active');

    // Close sidebar on mobile
    document.getElementById('sidebar').classList.remove('open');

    // Render page-specific content
    if (pageName === 'dashboard') renderDashboard();
    if (pageName === 'records')   renderRecords();
    if (pageName === 'analytics') renderAnalytics();
    if (pageName === 'export')    renderExport();
  }

  // ---- DASHBOARD ----
  function renderDashboard() {
    if (!records.length) {
      document.getElementById('kpi-total').textContent = 0;
      document.getElementById('kpi-avg-score').textContent = '0.0';
      document.getElementById('kpi-avg-satisfaction').textContent = '0.0';
      document.getElementById('kpi-top-dept').textContent = '—';
      return;
    }
    const total = records.length;
    const avgScore = (records.reduce((s, r) => s + r.score, 0) / total).toFixed(1);
    const avgSat = (records.reduce((s, r) => s + r.satisfaction, 0) / total).toFixed(1);

    // Top dept by count
    const deptCount = {};
    records.forEach(r => deptCount[r.department] = (deptCount[r.department] || 0) + 1);
    const topDept = Object.entries(deptCount).sort((a, b) => b[1] - a[1])[0][0];
    const shortDept = topDept.length > 10 ? topDept.split(' ')[0] : topDept;

    document.getElementById('kpi-total').textContent = total;
    document.getElementById('kpi-avg-score').textContent = avgScore;
    document.getElementById('kpi-avg-satisfaction').textContent = avgSat;
    document.getElementById('kpi-top-dept').textContent = shortDept;

    // Warnings
    renderWarnings();

    // Score distribution histogram
    const bins = [0, 0, 0, 0, 0]; // 0-19,20-39,40-59,60-79,80-100
    records.forEach(r => { const b = Math.min(4, Math.floor(r.score / 20)); bins[b]++; });
    createChart('chart-score-dist', {
      type: 'bar',
      data: {
        labels: ['0–19','20–39','40–59','60–79','80–100'],
        datasets: [{ label: 'Students', data: bins, backgroundColor: PALETTE.slice(0,5), borderRadius: 6 }]
      },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });

    // Dept doughnut
    const deptLabels = Object.keys(deptCount);
    const deptData = deptLabels.map(d => deptCount[d]);
    createChart('chart-dept', {
      type: 'doughnut',
      data: { labels: deptLabels, datasets: [{ data: deptData, backgroundColor: PALETTE, borderWidth: 2 }] },
      options: { responsive: true, plugins: { legend: { position: 'bottom', labels: { font: { size: 11 } } } } }
    });

    // Recent 5 entries
    const tbody = document.getElementById('recent-tbody');
    tbody.innerHTML = '';
    records.slice(-5).reverse().forEach(r => {
      tbody.innerHTML += `
        <tr>
          <td>${r.name}</td>
          <td>${r.department}</td>
          <td>${scoreBadge(r.score)}</td>
          <td>${r.satisfaction}/10</td>
          <td>${r.studyHours}h</td>
          <td>${r.date}</td>
        </tr>`;
    });

    // Update sidebar badge
    document.getElementById('record-count-badge').textContent = `${total} record${total !== 1 ? 's' : ''}`;
  }

  function renderWarnings() {
    const panel = document.getElementById('warning-panel');
    const warnings = [];
    const lowScore = records.filter(r => r.score < 50).length;
    const lowAttend = records.filter(r => r.attendance < 60).length;
    const lowSat = records.filter(r => r.satisfaction <= 3).length;
    if (lowScore > 0) warnings.push(`⚠️ ${lowScore} student(s) have scores below 50 — consider intervention.`);
    if (lowAttend > 0) warnings.push(`⚠️ ${lowAttend} student(s) have attendance below 60% — at risk.`);
    if (lowSat > 0) warnings.push(`⚠️ ${lowSat} student(s) rated satisfaction ≤ 3 — review experience.`);

    if (warnings.length) {
      panel.classList.remove('hidden');
      panel.innerHTML = `<h4>🔔 Threshold Warnings</h4><ul>${warnings.map(w => `<li>${w}</li>`).join('')}</ul>`;
    } else {
      panel.classList.add('hidden');
    }
  }

  // ---- RECORDS ----
  function getFilteredRecords() {
    const q = document.getElementById('search-input').value.trim().toLowerCase();
    const dept = document.getElementById('filter-dept').value;
    const year = document.getElementById('filter-year').value;
    const scoreRange = document.getElementById('filter-score').value;

    return records.filter(r => {
      if (q && !r.name.toLowerCase().includes(q) && !r.studentId.toLowerCase().includes(q)) return false;
      if (dept && r.department !== dept) return false;
      if (year && r.year !== year) return false;
      if (scoreRange) {
        const [lo, hi] = scoreRange.split('-').map(Number);
        if (r.score < lo || r.score > hi) return false;
      }
      return true;
    });
  }

  function renderRecords() {
    filteredRecords = getFilteredRecords();
    const total = filteredRecords.length;
    document.getElementById('filter-count').textContent = `Showing ${total} of ${records.length} records`;

    const totalPages = Math.max(1, Math.ceil(total / PAGE_SIZE));
    if (currentPage > totalPages) currentPage = 1;

    const pageRecords = filteredRecords.slice((currentPage - 1) * PAGE_SIZE, currentPage * PAGE_SIZE);

    const tbody = document.getElementById('records-tbody');
    tbody.innerHTML = '';
    if (!pageRecords.length) {
      tbody.innerHTML = '<tr><td colspan="11" style="text-align:center;color:#94a3b8;padding:30px">No records found</td></tr>';
    } else {
      pageRecords.forEach((r, i) => {
        tbody.innerHTML += `
          <tr>
            <td>${(currentPage - 1) * PAGE_SIZE + i + 1}</td>
            <td><strong>${r.name}</strong></td>
            <td><code>${r.studentId}</code></td>
            <td>${r.department}</td>
            <td>${r.year}</td>
            <td>${scoreBadge(r.score)}</td>
            <td>${r.satisfaction}/10</td>
            <td>${r.studyHours}h</td>
            <td>${r.attendance}%</td>
            <td>${r.date}</td>
            <td>
              <div class="action-btns">
                <button class="btn-icon" title="Edit" onclick="app.editRecord('${r.id}')">✏️</button>
                <button class="btn-icon" title="Delete" onclick="app.deleteRecord('${r.id}')">🗑️</button>
              </div>
            </td>
          </tr>`;
      });
    }

    // Pagination
    const pag = document.getElementById('pagination');
    pag.innerHTML = '';
    for (let p = 1; p <= totalPages; p++) {
      const btn = document.createElement('button');
      btn.className = `page-btn${p === currentPage ? ' active' : ''}`;
      btn.textContent = p;
      btn.onclick = () => { currentPage = p; renderRecords(); };
      pag.appendChild(btn);
    }
  }

  // ---- ANALYTICS ----
  function renderAnalytics() {
    if (!records.length) return;
    const n = records.length;
    const scores = records.map(r => r.score);
    const sats = records.map(r => r.satisfaction);
    const hours = records.map(r => r.studyHours);
    const attends = records.map(r => r.attendance);

    const avg = arr => (arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(1);
    const max = arr => Math.max(...arr);
    const min = arr => Math.min(...arr);

    // Stats cards
    const statsEl = document.getElementById('analytics-stats');
    const stats = [
      { label: 'Total Students', value: n },
      { label: 'Avg Score', value: avg(scores) },
      { label: 'Max Score', value: max(scores) },
      { label: 'Min Score', value: min(scores) },
      { label: 'Avg Satisfaction', value: avg(sats) },
      { label: 'Avg Study Hrs', value: avg(hours) },
      { label: 'Avg Attendance', value: avg(attends) + '%' },
      { label: 'Score ≥ 75', value: scores.filter(s => s >= 75).length },
    ];
    statsEl.innerHTML = stats.map(s =>
      `<div class="stat-card"><div class="stat-label">${s.label}</div><div class="stat-value">${s.value}</div></div>`
    ).join('');

    // Scatter: Satisfaction vs Score
    createChart('chart-scatter', {
      type: 'scatter',
      data: {
        datasets: [{
          label: 'Students',
          data: records.map(r => ({ x: r.score, y: r.satisfaction })),
          backgroundColor: '#6366f180',
          pointRadius: 6
        }]
      },
      options: {
        responsive: true,
        scales: {
          x: { title: { display: true, text: 'Score' }, min: 0, max: 100 },
          y: { title: { display: true, text: 'Satisfaction' }, min: 0, max: 11 }
        },
        plugins: { legend: { display: false } }
      }
    });

    // Study hours histogram
    const studyBins = [0,0,0,0,0];
    hours.forEach(h => { const b = Math.min(4, Math.floor(h / 10)); studyBins[b]++; });
    createChart('chart-study-hours', {
      type: 'bar',
      data: {
        labels: ['0–9h','10–19h','20–29h','30–39h','40+h'],
        datasets: [{ label: 'Students', data: studyBins, backgroundColor: '#06b6d4', borderRadius: 6 }]
      },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });

    // Attendance histogram
    const attendBins = [0,0,0,0,0];
    attends.forEach(a => { const b = Math.min(4, Math.floor(a / 20)); attendBins[b]++; });
    createChart('chart-attendance', {
      type: 'bar',
      data: {
        labels: ['0–19%','20–39%','40–59%','60–79%','80–100%'],
        datasets: [{ label: 'Students', data: attendBins, backgroundColor: '#22c55e', borderRadius: 6 }]
      },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
    });

    // Score by department (box-like via bar)
    const depts = [...new Set(records.map(r => r.department))].sort();
    const deptAvgScore = depts.map(d => {
      const rs = records.filter(r => r.department === d);
      return (rs.reduce((s, r) => s + r.score, 0) / rs.length).toFixed(1);
    });
    createChart('chart-dept-score', {
      type: 'bar',
      data: {
        labels: depts.map(d => d.split(' ')[0]),
        datasets: [{ label: 'Avg Score', data: deptAvgScore, backgroundColor: PALETTE, borderRadius: 6 }]
      },
      options: { responsive: true, plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true, max: 100 } } }
    });

    // Year-wise satisfaction
    const yearOrder = ['1st Year','2nd Year','3rd Year','4th Year','Postgraduate'];
    const presentYears = yearOrder.filter(y => records.some(r => r.year === y));
    const yearAvgSat = presentYears.map(y => {
      const rs = records.filter(r => r.year === y);
      return (rs.reduce((s, r) => s + r.satisfaction, 0) / rs.length).toFixed(1);
    });
    createChart('chart-year-satisfaction', {
      type: 'line',
      data: {
        labels: presentYears.map(y => y.replace(' Year','Y').replace('Postgraduate','PG')),
        datasets: [{
          label: 'Avg Satisfaction',
          data: yearAvgSat,
          borderColor: '#f59e0b',
          backgroundColor: '#fef3c740',
          fill: true,
          tension: 0.4,
          pointRadius: 5
        }]
      },
      options: { responsive: true, scales: { y: { beginAtZero: true, max: 11 } } }
    });

    // Score trend (entry order)
    createChart('chart-score-trend', {
      type: 'line',
      data: {
        labels: records.map((_, i) => i + 1),
        datasets: [{
          label: 'Score',
          data: records.map(r => r.score),
          borderColor: '#6366f1',
          backgroundColor: '#6366f120',
          fill: true,
          tension: 0.3,
          pointRadius: 3
        }]
      },
      options: {
        responsive: true,
        plugins: { legend: { display: false } },
        scales: { y: { beginAtZero: true, max: 105 } }
      }
    });
  }

  // ---- EXPORT ----
  function generateCSV() {
    const headers = ['name','studentId','department','year','score','satisfaction','studyHours','attendance','feedback','date'];
    const rows = records.map(r => headers.map(h => `"${String(r[h] || '').replace(/"/g, '""')}"`).join(','));
    return [headers.join(','), ...rows].join('\n');
  }

  function generateMarkdown() {
    const n = records.length;
    if (!n) return '# No data available';
    const avg = arr => (arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(2);
    const scores = records.map(r => r.score);
    const sats = records.map(r => r.satisfaction);
    const deptCount = {};
    records.forEach(r => deptCount[r.department] = (deptCount[r.department] || 0) + 1);

    return `# Student Survey Dashboard — Summary Report
> Generated: ${new Date().toLocaleString()}

## Overview

| Metric | Value |
|--------|-------|
| Total Responses | ${n} |
| Average Score | ${avg(scores)} |
| Average Satisfaction | ${avg(sats)} / 10 |
| Max Score | ${Math.max(...scores)} |
| Min Score | ${Math.min(...scores)} |
| Avg Study Hours | ${avg(records.map(r => r.studyHours))}h |
| Avg Attendance | ${avg(records.map(r => r.attendance))}% |

## Department Breakdown

| Department | Count | Avg Score |
|-----------|-------|-----------|
${Object.entries(deptCount).sort((a,b) => b[1]-a[1]).map(([d, c]) => {
  const rs = records.filter(r => r.department === d);
  const avgS = (rs.reduce((s, r) => s + r.score, 0) / rs.length).toFixed(1);
  return `| ${d} | ${c} | ${avgS} |`;
}).join('\n')}

## Warning Indicators

${records.filter(r => r.score < 50).length > 0 ? `- ⚠️ **${records.filter(r => r.score < 50).length}** students scored below 50` : '- ✅ No students below score threshold'}
${records.filter(r => r.attendance < 60).length > 0 ? `- ⚠️ **${records.filter(r => r.attendance < 60).length}** students have attendance < 60%` : '- ✅ No attendance issues detected'}
${records.filter(r => r.satisfaction <= 3).length > 0 ? `- ⚠️ **${records.filter(r => r.satisfaction <= 3).length}** students rated satisfaction ≤ 3` : '- ✅ Satisfaction levels healthy'}

---
*LocalImpact Challenge · Project #100 · Student Survey Dashboard*`;
  }

  function generatePlainText() {
    const n = records.length;
    if (!n) return 'No data available.';
    const avg = arr => (arr.reduce((a, b) => a + b, 0) / arr.length).toFixed(2);
    const scores = records.map(r => r.score);
    const deptCount = {};
    records.forEach(r => deptCount[r.department] = (deptCount[r.department] || 0) + 1);

    const lines = [
      '=' .repeat(55),
      ' STUDENT SURVEY DASHBOARD — SUMMARY REPORT',
      '=' .repeat(55),
      `Generated : ${new Date().toLocaleString()}`,
      '-'.repeat(55),
      `Total Responses : ${n}`,
      `Average Score   : ${avg(scores)}`,
      `Average Sat.    : ${avg(records.map(r => r.satisfaction))} / 10`,
      `Max Score       : ${Math.max(...scores)}`,
      `Min Score       : ${Math.min(...scores)}`,
      `Avg Study Hrs   : ${avg(records.map(r => r.studyHours))}h`,
      `Avg Attendance  : ${avg(records.map(r => r.attendance))}%`,
      '-'.repeat(55),
      ' DEPARTMENT BREAKDOWN',
      '-'.repeat(55),
      ...Object.entries(deptCount).sort((a,b) => b[1]-a[1]).map(([d, c]) => {
        const rs = records.filter(r => r.department === d);
        const avgS = (rs.reduce((s, r) => s + r.score, 0) / rs.length).toFixed(1);
        return `  ${d.padEnd(22)} Count: ${String(c).padEnd(4)} Avg: ${avgS}`;
      }),
      '-'.repeat(55),
      ' WARNINGS',
      '-'.repeat(55),
      ...[ records.filter(r => r.score < 50).length > 0 ? `  [!] ${records.filter(r => r.score < 50).length} students below score 50` : '  [OK] No score threshold breaches',
           records.filter(r => r.attendance < 60).length > 0 ? `  [!] ${records.filter(r => r.attendance < 60).length} students below 60% attendance` : '  [OK] Attendance within acceptable range',
           records.filter(r => r.satisfaction <= 3).length > 0 ? `  [!] ${records.filter(r => r.satisfaction <= 3).length} students rated satisfaction <= 3` : '  [OK] Satisfaction levels healthy' ],
      '='.repeat(55)
    ];
    return lines.join('\n');
  }

  function renderExport() {
    renderPreview();
  }

  function renderPreview() {
    const fmt = document.getElementById('preview-format').value;
    const el = document.getElementById('report-preview');
    if (fmt === 'md') el.textContent = generateMarkdown();
    else if (fmt === 'txt') el.textContent = generatePlainText();
    else el.textContent = JSON.stringify(records, null, 2);
  }

  function downloadFile(content, filename, mime) {
    const blob = new Blob([content], { type: mime });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    URL.revokeObjectURL(a.href);
  }

  // ---- ADD / EDIT / DELETE ----
  function getFormValues(prefix = 'f') {
    return {
      name: document.getElementById(`${prefix}-name`).value.trim(),
      studentId: document.getElementById(`${prefix}-student-id`).value.trim(),
      department: document.getElementById(`${prefix}-dept`).value,
      year: document.getElementById(`${prefix}-year`).value,
      score: Number(document.getElementById(`${prefix}-score`).value),
      satisfaction: Number(document.getElementById(`${prefix}-satisfaction`).value),
      studyHours: Number(document.getElementById(`${prefix}-study-hours`).value),
      attendance: Number(document.getElementById(`${prefix}-attendance`).value),
      feedback: document.getElementById(`${prefix}-feedback`).value.trim()
    };
  }

  function validateForm(data, prefix = 'f') {
    const fields = { name: 'name', studentId: 'student-id', department: 'dept', year: 'year',
                     score: 'score', satisfaction: 'satisfaction', studyHours: 'study-hours', attendance: 'attendance' };
    let valid = true;
    Object.entries(fields).forEach(([key, fieldId]) => {
      const err = validateField(key, data[key] ?? data[key]);
      const errEl = document.getElementById(`${prefix === 'f' ? 'err' : 'e-err'}-${fieldId.replace('student-id','student-id').replace('study-hours','study-hours')}`);
      if (errEl) {
        errEl.textContent = err;
        const input = document.getElementById(`${prefix}-${fieldId}`);
        if (input) input.classList.toggle('invalid', !!err);
      }
      if (err) valid = false;
    });
    return valid;
  }

  function handleAddSubmit(e) {
    e.preventDefault();
    const data = getFormValues('f');
    // Manual validation for add form
    const fields = [
      { key: 'name', id: 'err-name', inputId: 'f-name' },
      { key: 'studentId', id: 'err-student-id', inputId: 'f-student-id' },
      { key: 'dept', id: 'err-dept', inputId: 'f-dept' },
      { key: 'year', id: 'err-year', inputId: 'f-year' },
      { key: 'score', id: 'err-score', inputId: 'f-score' },
      { key: 'satisfaction', id: 'err-satisfaction', inputId: 'f-satisfaction' },
      { key: 'studyHours', id: 'err-study-hours', inputId: 'f-study-hours' },
      { key: 'attendance', id: 'err-attendance', inputId: 'f-attendance' }
    ];
    let valid = true;
    fields.forEach(f => {
      const val = f.key === 'dept' ? data.department : f.key === 'year' ? data.year : data[f.key];
      const err = validateField(f.key === 'dept' ? 'dept' : f.key === 'year' ? 'year' : f.key, val);
      document.getElementById(f.id).textContent = err;
      document.getElementById(f.inputId).classList.toggle('invalid', !!err);
      if (err) valid = false;
    });
    if (!valid) { toast('Please fix the errors above.', 'error'); return; }

    // Check duplicate ID
    if (records.some(r => r.studentId === data.studentId)) {
      document.getElementById('err-student-id').textContent = 'Student ID already exists.';
      document.getElementById('f-student-id').classList.add('invalid');
      toast('Student ID already exists!', 'error');
      return;
    }

    const record = { id: generateId(), ...data, date: new Date().toISOString().split('T')[0] };
    records.push(record);
    saveData(records);
    toast(`✅ Entry for ${data.name} saved!`, 'success');
    document.getElementById('entry-form').reset();
    document.getElementById('record-count-badge').textContent = `${records.length} records`;
  }

  function editRecord(id) {
    const r = records.find(r => r.id === id);
    if (!r) return;
    document.getElementById('e-id').value = r.id;
    document.getElementById('e-name').value = r.name;
    document.getElementById('e-student-id').value = r.studentId;
    document.getElementById('e-dept').value = r.department;
    document.getElementById('e-year').value = r.year;
    document.getElementById('e-score').value = r.score;
    document.getElementById('e-satisfaction').value = r.satisfaction;
    document.getElementById('e-study-hours').value = r.studyHours;
    document.getElementById('e-attendance').value = r.attendance;
    document.getElementById('e-feedback').value = r.feedback || '';
    document.getElementById('edit-modal').classList.remove('hidden');
  }

  function handleEditSubmit(e) {
    e.preventDefault();
    const id = document.getElementById('e-id').value;
    const data = getFormValues('e');

    // Validate
    const fields = [
      { key: 'name', id: 'e-err-name', inputId: 'e-name' },
      { key: 'score', id: 'e-err-score', inputId: 'e-score' },
      { key: 'satisfaction', id: 'e-err-satisfaction', inputId: 'e-satisfaction' }
    ];
    let valid = true;
    fields.forEach(f => {
      const err = validateField(f.key, data[f.key]);
      document.getElementById(f.id).textContent = err;
      document.getElementById(f.inputId).classList.toggle('invalid', !!err);
      if (err) valid = false;
    });
    if (!valid) return;

    const idx = records.findIndex(r => r.id === id);
    if (idx === -1) return;
    records[idx] = { ...records[idx], ...data };
    saveData(records);
    toast(`✅ Record updated!`, 'success');
    document.getElementById('edit-modal').classList.add('hidden');
    renderRecords();
  }

  function deleteRecord(id) {
    const r = records.find(r => r.id === id);
    if (!r) return;
    if (!confirm(`Delete entry for "${r.name}"? This cannot be undone.`)) return;
    records = records.filter(r => r.id !== id);
    saveData(records);
    toast(`🗑️ Entry deleted.`, 'warning');
    document.getElementById('record-count-badge').textContent = `${records.length} records`;
    renderRecords();
  }

  // ---- BULK CSV IMPORT ----
  function handleCSVImport(file) {
    if (!file) return;
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        let added = 0, errors = 0;
        const errorRows = [];
        results.data.forEach((row, i) => {
          const rec = {
            id: generateId(),
            name: row.name || row.Name || '',
            studentId: row.studentId || row.student_id || row['Student ID'] || '',
            department: row.department || row.Department || '',
            year: row.year || row.Year || '',
            score: Number(row.score || row.Score || 0),
            satisfaction: Number(row.satisfaction || row.Satisfaction || 0),
            studyHours: Number(row.studyHours || row.study_hours || row['Study Hours'] || 0),
            attendance: Number(row.attendance || row.Attendance || 0),
            feedback: row.feedback || row.Feedback || '',
            date: row.date || new Date().toISOString().split('T')[0]
          };
          // Basic validation
          const nameErr = validateField('name', rec.name);
          const scoreErr = validateField('score', rec.score);
          if (nameErr || scoreErr) { errors++; errorRows.push(i + 2); return; }
          if (records.some(r => r.studentId === rec.studentId && rec.studentId)) { errors++; return; }
          records.push(rec);
          added++;
        });
        saveData(records);
        document.getElementById('record-count-badge').textContent = `${records.length} records`;
        toast(`📥 Imported ${added} record(s)${errors ? `, ${errors} skipped` : ''}.`, added > 0 ? 'success' : 'warning');
        renderRecords();
      },
      error: (err) => toast('CSV parse error: ' + err.message, 'error')
    });
  }

  // ---- INIT ----
  function init() {
    records = loadData();
    if (!records.length) {
      records = seedSampleData();
      toast('📊 Sample data loaded (35 students). Ready to explore!', 'success', 4000);
    }

    // Navigation
    document.querySelectorAll('.nav-item').forEach(item => {
      item.addEventListener('click', e => {
        e.preventDefault();
        nav(item.dataset.page);
      });
    });

    // "View All" and other page-link buttons
    document.querySelectorAll('[data-page]').forEach(btn => {
      if (btn.classList.contains('nav-item')) return; // already handled
      btn.addEventListener('click', e => { e.preventDefault(); nav(btn.dataset.page); });
    });

    // Mobile hamburger
    document.getElementById('hamburger').addEventListener('click', () => {
      document.getElementById('sidebar').classList.toggle('open');
    });

    // Add form
    document.getElementById('entry-form').addEventListener('submit', handleAddSubmit);
    document.getElementById('clear-form-btn').addEventListener('click', () => {
      document.querySelectorAll('.field-error').forEach(el => el.textContent = '');
      document.querySelectorAll('.invalid').forEach(el => el.classList.remove('invalid'));
    });

    // Real-time validation on add form
    ['f-name','f-student-id','f-score','f-satisfaction','f-study-hours','f-attendance'].forEach(id => {
      const el = document.getElementById(id);
      if (!el) return;
      el.addEventListener('input', () => {
        const keyMap = { 'f-name':'name','f-student-id':'studentId','f-score':'score','f-satisfaction':'satisfaction','f-study-hours':'studyHours','f-attendance':'attendance' };
        const errMap = { 'f-name':'err-name','f-student-id':'err-student-id','f-score':'err-score','f-satisfaction':'err-satisfaction','f-study-hours':'err-study-hours','f-attendance':'err-attendance' };
        const key = keyMap[id];
        const err = validateField(key, el.value);
        document.getElementById(errMap[id]).textContent = err;
        el.classList.toggle('invalid', !!err);
      });
    });

    // Edit modal
    document.getElementById('edit-form').addEventListener('submit', handleEditSubmit);
    document.getElementById('close-modal').addEventListener('click', () => document.getElementById('edit-modal').classList.add('hidden'));
    document.getElementById('cancel-edit').addEventListener('click', () => document.getElementById('edit-modal').classList.add('hidden'));
    document.getElementById('edit-modal').addEventListener('click', e => { if (e.target === e.currentTarget) e.currentTarget.classList.add('hidden'); });

    // Filters
    ['search-input','filter-dept','filter-year','filter-score'].forEach(id => {
      document.getElementById(id).addEventListener('input', () => { currentPage = 1; renderRecords(); });
    });
    document.getElementById('clear-filters').addEventListener('click', () => {
      document.getElementById('search-input').value = '';
      document.getElementById('filter-dept').value = '';
      document.getElementById('filter-year').value = '';
      document.getElementById('filter-score').value = '';
      currentPage = 1;
      renderRecords();
    });

    // CSV Import
    document.getElementById('csv-import').addEventListener('change', e => handleCSVImport(e.target.files[0]));

    // Export buttons
    document.getElementById('export-csv').addEventListener('click', () => {
      downloadFile(generateCSV(), 'survey_data.csv', 'text/csv');
      toast('📄 CSV downloaded!', 'success');
    });
    document.getElementById('export-json').addEventListener('click', () => {
      downloadFile(JSON.stringify(records, null, 2), 'survey_data.json', 'application/json');
      toast('{ } JSON downloaded!', 'success');
    });
    document.getElementById('export-md').addEventListener('click', () => {
      downloadFile(generateMarkdown(), 'survey_report.md', 'text/markdown');
      toast('📝 Markdown report downloaded!', 'success');
    });
    document.getElementById('export-txt').addEventListener('click', () => {
      downloadFile(generatePlainText(), 'survey_report.txt', 'text/plain');
      toast('📃 Text report downloaded!', 'success');
    });
    document.getElementById('preview-format').addEventListener('change', renderPreview);

    // Render initial page
    renderDashboard();
    document.getElementById('record-count-badge').textContent = `${records.length} records`;
  }

  return { init, nav, editRecord, deleteRecord };
})();

document.addEventListener('DOMContentLoaded', app.init);
